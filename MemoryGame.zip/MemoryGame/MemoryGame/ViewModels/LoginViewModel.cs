﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Microsoft.Win32;
using Newtonsoft.Json;
using MemoryGame.Commands;
using MemoryGame.Models;
using System.Xml;
using System.Windows;

namespace MemoryGame.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private const string UsersFile = "users.json";

        public ObservableCollection<User> Users { get; set; }

        private User _selectedUser;
        public User SelectedUser
        {
            get { return _selectedUser; }
            set { _selectedUser = value; OnPropertyChanged(); }
        }

        public ICommand AddUserCommand { get; private set; }
        public ICommand DeleteUserCommand { get; private set; }
        public ICommand PlayCommand { get; private set; }
        public ICommand PreviousUserCommand { get; }
        public ICommand NextUserCommand { get; }
 

        public LoginViewModel()
        {
            Users = new ObservableCollection<User>();
            LoadUsers();

            AddUserCommand = new RelayCommand(AddUser);
            DeleteUserCommand = new RelayCommand(DeleteUser, CanDeleteOrPlay);
            PlayCommand = new RelayCommand(Play, CanDeleteOrPlay);
            PreviousUserCommand = new RelayCommand(GoToPreviousUser, _ => Users.Count > 1);
            NextUserCommand = new RelayCommand(GoToNextUser, _ => Users.Count > 1);
        }
         

        private void GoToPreviousUser(object obj)
        {
            int index = Users.IndexOf(SelectedUser);
            if (index > 0)
                SelectedUser = Users[index - 1];
        }

        private void GoToNextUser(object obj)
        {
            int index = Users.IndexOf(SelectedUser);
            if (index < Users.Count - 1)
                SelectedUser = Users[index + 1];
        }
        private void AddUser(object obj)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif";

            if (dialog.ShowDialog() == true)
            {
                string imagePath = dialog.FileName.Replace(Directory.GetCurrentDirectory() + "\\", "").Replace("\\", "/");
                string username = Path.GetFileNameWithoutExtension(dialog.FileName).Replace(" ", "_");

                if (!Users.Any(u => u.Username == username))
                {
                    Users.Add(new User { Username = username, ImagePath = imagePath });
                    SaveUsers();
                }
            }
        }

        private void DeleteUser(object obj)
        {
            if (SelectedUser != null)
            {
                Users.Remove(SelectedUser);
                SelectedUser = null;
                SaveUsers();
            }
        }

        private void Play(object obj)
        {
            var gameWindow = new MemoryGame.Views.GameView();
            gameWindow.Show();

            // Închide fereastra curentă (LoginView)
            foreach (System.Windows.Window window in System.Windows.Application.Current.Windows)
            {
                if (window is MemoryGame.Views.LoginView)
                {
                    window.Close();
                    break;
                }
            }
        }


        private bool CanDeleteOrPlay(object obj)
        {
            return SelectedUser != null;
        }

        private void LoadUsers()
        {
            if (File.Exists(UsersFile))
            {
                var json = File.ReadAllText(UsersFile);
                var list = JsonConvert.DeserializeObject<ObservableCollection<User>>(json);
                if (list != null)
                    foreach (var user in list)
                        Users.Add(user);
            }
        }

        private void SaveUsers()
        {
            var json = JsonConvert.SerializeObject(Users, Newtonsoft.Json.Formatting.Indented);

            File.WriteAllText(UsersFile, json);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
