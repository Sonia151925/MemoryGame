﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using MemoryGame.Commands;
using MemoryGame.Models;
using System.Windows.Threading;
using Newtonsoft.Json;
using System.Collections.Generic;
 

namespace MemoryGame.ViewModels
{
    public class GameViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Card> Cards { get; set; }
        public ICommand FlipCardCommand { get; set; }
        public string CurrentCategory { get; set; } = "Animals";

        private Card _firstFlipped;
        private bool _isBusy;
        private DispatcherTimer _timer;
        private int _secondsRemaining = 120;
        public string CurrentUsername { get; set; } = "Guest"; // sau setezi când se deschide fereastra
        public int Rows { get; set; } = 4;
        public int Columns { get; set; } = 4;
        public int TotalTime { get; set; } = 60; // timp implicit standard (secunde)




        public string TimeDisplay => $"Timp rămas: {_secondsRemaining}s";
        public GameViewModel()
        {
            Cards = new ObservableCollection<Card>();
            FlipCardCommand = new RelayCommand(FlipCard, CanFlipCard);
            GenerateBoard();
            StartTimer();

        }
        private void StartTimer()
        {
            _secondsRemaining = TotalTime;
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += (s, e) =>
            {
                _secondsRemaining--;
                OnPropertyChanged(nameof(TimeDisplay));

                if (_secondsRemaining <= 0)
                {
                    _timer.Stop();
                    MessageBox.Show("Timpul a expirat! Joc pierdut.");
                    RegenerateBoard();
                }
            };
            _timer.Start();
        }

        private bool CanFlipCard(object obj)
        {
            return !_isBusy && obj is Card c && !c.IsFlipped && !c.IsMatched;
        }

        private async void FlipCard(object obj)
        {
            MessageBox.Show("Card flipped!");

            if (_isBusy || !(obj is Card clickedCard) || clickedCard.IsFlipped || clickedCard.IsMatched)
                return;

            if (_firstFlipped == clickedCard)
                return;

            clickedCard.IsFlipped = true;
            OnPropertyChanged(nameof(Cards));

            if (_firstFlipped == null)
            {
                _firstFlipped = clickedCard;
                return;
            }

            _isBusy = true;
            await Task.Delay(1000);

            if (_firstFlipped.ImagePath == clickedCard.ImagePath)
            {
                _firstFlipped.IsMatched = true;
                clickedCard.IsMatched = true;
                CheckWinCondition();
            }
            else
            {
                _firstFlipped.IsFlipped = false;
                clickedCard.IsFlipped = false;
            }

            _firstFlipped = null;
            _isBusy = false;
            OnPropertyChanged(nameof(Cards));
        }

        private void GenerateBoard()
        {
            string imageFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", CurrentCategory);

            if (!Directory.Exists(imageFolder))
            {
                MessageBox.Show("Folderul cu imagini nu există: " + imageFolder);
                return;
            }

            var imageFiles = Directory.GetFiles(imageFolder, "*.*")
                .Where(f => f.EndsWith(".jpg") || f.EndsWith(".png") || f.EndsWith(".gif"))
                .ToList();

            int totalCards = Rows * Columns;
            int neededImages = totalCards / 2;

            if (imageFiles.Count < neededImages)
            {
                MessageBox.Show($"Ai nevoie de cel puțin {neededImages} imagini în {imageFolder}");
                return;
            }

            var rnd = new Random();
            var selectedImages = imageFiles.OrderBy(x => rnd.Next()).Take(neededImages).ToList();
            var allImages = selectedImages.Concat(selectedImages).OrderBy(x => rnd.Next()).ToList();

            Cards.Clear();
            foreach (var image in allImages)
            {
                Cards.Add(new Card
                {
                    ImagePath = new Uri(image, UriKind.Absolute).AbsoluteUri,
                    IsFlipped = false,
                    IsMatched = false
                });
            }
        }


        public void RegenerateBoard()
        {
            Cards.Clear();
            GenerateBoard();
            StartTimer(); // pornește timerul din nou

        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        

public void SaveCurrentGame(string username)
    {
        var save = new SavedGame
        {
            Category = CurrentCategory,
            SecondsRemaining = _secondsRemaining,
            Cards = Cards.ToList() // convert ObservableCollection în List
        };

        var json = JsonConvert.SerializeObject(save, Formatting.Indented);
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SavedGames", $"{username}_Game.json");

        Directory.CreateDirectory(Path.GetDirectoryName(path));
        File.WriteAllText(path, json);
            MessageBox.Show("Joc salvat cu succes!\n" + path);

            MessageBox.Show("Joc salvat cu succes!");
    }
        public void LoadSavedGame(string username)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SavedGames", $"{username}_Game.json");

            if (!File.Exists(path))
            {
                MessageBox.Show("Nu există joc salvat pentru acest utilizator.");
                return;
            }

            var json = File.ReadAllText(path);
            var save = JsonConvert.DeserializeObject<SavedGame>(json);

            CurrentCategory = save.Category;
            _secondsRemaining = save.SecondsRemaining;

            Cards.Clear();
            foreach (var card in save.Cards)
                Cards.Add(card);

            OnPropertyChanged(nameof(Cards));
            MessageBox.Show("Joc încărcat cu succes!");
        }

        public void UpdateStats(string username, bool won)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SavedGames", "stats.json");

            List<UserStats> stats;
            if (File.Exists(path))
            {
                var json = File.ReadAllText(path);
                stats = JsonConvert.DeserializeObject<List<UserStats>>(json) ?? new List<UserStats>();
            }
            else
            {
                stats = new List<UserStats>();
            }

            var userStat = stats.FirstOrDefault(s => s.Username == username);
            if (userStat == null)
            {
                userStat = new UserStats { Username = username, GamesPlayed = 0, GamesWon = 0 };
                stats.Add(userStat);
            }

            userStat.GamesPlayed++;
            if (won)
                userStat.GamesWon++;

            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, JsonConvert.SerializeObject(stats, Formatting.Indented));
        }
        public void SetTime(int seconds)
        {
            _secondsRemaining = seconds;
        }

        public void ShowStats()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SavedGames", "stats.json");

            if (!File.Exists(path))
            {
                MessageBox.Show("Nu există statistici salvate.");
                return;
            }

            var json = File.ReadAllText(path);
            var stats = JsonConvert.DeserializeObject<List<UserStats>>(json);

            if (stats == null || stats.Count == 0)
            {
                MessageBox.Show("Nicio statistică disponibilă.");
                return;
            }

            string message = string.Join("\n", stats.Select(s =>
                $"{s.Username} – Jucate: {s.GamesPlayed}, Castigate: {s.GamesWon}"));

            MessageBox.Show(message, "Statistici utilizatori");
        }
        private void CheckWinCondition()
        {
            if (Cards.All(c => c.IsMatched))
            {
                _timer.Stop(); // oprește timerul
                MessageBox.Show("Felicitări! Ai câștigat jocul!");
                UpdateStats(CurrentUsername, true);
            }
        }



    }
}
