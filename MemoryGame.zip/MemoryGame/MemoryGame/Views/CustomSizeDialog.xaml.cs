﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MemoryGame.Views
{
    public partial class CustomSizeDialog : Window
    {
        public int Rows { get; private set; }
        public int Columns { get; private set; }
        public int TimeSeconds { get; private set; }


        public CustomSizeDialog()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(RowsTextBox.Text, out int r) &&
                int.TryParse(ColsTextBox.Text, out int c) &&
                int.TryParse(TimeTextBox.Text, out int t) &&
                r >= 2 && r <= 6 && c >= 2 && c <= 6 && (r * c) % 2 == 0 && t > 0)
            {
                Rows = r;
                Columns = c;
                TimeSeconds = t;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Introduceți valori valide (2-6 pentru rânduri și coloane, timp > 0). Numărul total de jetoane trebuie să fie par.");
            }
        }
    }
}
