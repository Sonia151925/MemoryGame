﻿using System;
using System.Windows;
using System.Windows.Controls;
using MemoryGame.ViewModels;

namespace MemoryGame.Views
{
    public partial class GameView : Window
    {
        public GameView()
        {
            InitializeComponent();
            DataContext = new ViewModels.GameViewModel(); // Legăm ViewModel-ul
        }

        private void Category_Click(object sender, RoutedEventArgs e)
        {
            var item = sender as MenuItem;
            string selectedCategory = item?.Tag?.ToString();

            var vm = DataContext as GameViewModel;
            if (vm != null)
            {
                vm.CurrentCategory = selectedCategory;
                vm.RegenerateBoard(); // trebuie să existe metoda asta
                MessageBox.Show("Categoria setată: " + selectedCategory);
            }
        }


        private void NewGame_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Joc nou pornit!");
          
            if (DataContext is GameViewModel viewModel)
            {
                viewModel.RegenerateBoard();
            }
        }

        

        private void OpenGame_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is GameViewModel vm)
                vm.LoadSavedGame("student");
        }

        private void SaveGame_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is GameViewModel viewModel)
            {
                // aici poți înlocui "student" cu utilizatorul curent dacă îl ai
                viewModel.SaveCurrentGame("student");
            }
        }

        private void Statistics_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is GameViewModel vm)
                vm.ShowStats();
        }


        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // FUNCȚIONEAZĂ aici
        }

        private void Standard_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is GameViewModel vm)
            {
                vm.Rows = 4;
                vm.Columns = 4;
                vm.TotalTime = 120; // ex: 2 minute
                vm.RegenerateBoard();
            }
        }

        private void Custom_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CustomSizeDialog();
            dialog.Owner = this;

            if (dialog.ShowDialog() == true)
            {
                if (DataContext is GameViewModel vm)
                {
                    vm.Rows = dialog.Rows;
                    vm.Columns = dialog.Columns;
                    vm.SetTime(dialog.TimeSeconds);
                    vm.RegenerateBoard();
                }
            }

        }


        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Nume: KICSI SONIA\nEmail: sonia.kicsi@student.unitbv.ro\nGrupa: 10LF332\nSpecializare: Info Aplicata",
                "Despre", MessageBoxButton.OK, MessageBoxImage.Information);
        }


    }
}
