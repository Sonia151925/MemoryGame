﻿using System.Collections.Generic;

namespace MemoryGame.Models
{
    public class SavedGame
    {
        public string Category { get; set; }
        public int SecondsRemaining { get; set; }
        public List<Card> Cards { get; set; }
    }
}
